// Función simplificada para calcular el promedio de números mayores a un valor dado
function calcularPromedio() {
  // Obtener los valores ingresados por el usuario
  const numerosStr = document.getElementById("numeros").value;
  const limiteStr = document.getElementById("limite").value;
  const respuesta = document.getElementById("resp");

  // Convertir la lista de números y el límite en enteros
  const numeros = numerosStr.split(';').map(num => parseFloat(num.trim()));
  const limite = parseFloat(limiteStr);

  // Inicializar variables para la suma y el conteo
  let suma = 0;
  let conteo = 0;

  // Recorrer el arreglo de números y calcular la suma de los que son mayores al límite
  for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] > limite) {
      suma += numeros[i];
      conteo++;
    }
  }

  // Calcular el promedio si hay números que cumplan la condición
  let promedio = 0;
  if (conteo > 0) {
    promedio = suma / conteo;
    respuesta.innerHTML = `Promedio: ${promedio.toFixed(2)}`;
  } else {
    respuesta.innerHTML = "No hay números mayores que el límite.";
  }
}




function arr1(){
  debugger
   let numer =[]
          for(let i=0;i<10;i++){
      numer.push(Math.floor(Math.random()*100) +1)

  }
  document.getElementById('numero').innerText = numer.join(', ')


}

function arr2() {
  // Obtener las calificaciones ingresadas
  let notas = document.getElementById('x1').value
  
  // Convertir las calificaciones en un arreglo numérico
  let prome = notas.split(',').map(num => parseFloat(num.trim()))

  // Validar que se ingresen 5 calificaciones válidas
  if (prome.length !== 5 || prome.some(isNaN)) {
    document.getElementById('prome').value = "Por favor ingrese 5 calificaciones válidas."
    return
  }

  let suma = prome.reduce((acc, curr) => acc + curr, 0)

  let promedio = suma / prome.length

  document.getElementById('prome').value = `El promedio es: ${promedio.toFixed(2)}`
}

function arr3() {
  debugger

  let datos = document.getElementById('numeros').value

  let numeros = datos.split(',').map(num => parseFloat(num.trim()))

  if (numeros.some(isNaN)) {
    document.getElementById("maximo").value = "!Error: Ingresa solo números válidos."
    return
  }
  let maximo = Math.max(...numeros)
  document.getElementById('maximo').value = `El número más grande es: ${maximo}`
}

function arre4() {
  // Obtener los valores ingresados
  let datos = document.getElementById('numeros').value
  let limite = parseFloat(document.getElementById('limite').value)

  // Convertir los datos en un arreglo de números
  let numeros = datos.split(',').map(num => parseFloat(num.trim()))

  // Filtrar los números mayores al valor límite
  let mayoresAlLimite = numeros.filter(num => num > limite)

  // Verificar si hay números mayores al límite
  if (mayoresAlLimite.length === 0) {
    document.getElementById('promedio').value = "No hay números mayores al valor límite."
    return
  }

  // Calcular el promedio de los números mayores al límite
  let suma = mayoresAlLimite.reduce((acc, curr) => acc + curr, 0)
  let promedio = suma / mayoresAlLimite.length

  // Mostrar el resultado en el área de texto
  document.getElementById('promedio').value = `El promedio de los números mayores a ${limite} es: ${promedio.toFixed(2)}`
}
function arre5() {
  // Obtener los valores ingresados
  let datos = document.getElementById('numeros').value

  // Convertir los datos en un arreglo de números
  let numeros = datos.split(',').map(num => parseFloat(num.trim()))

  // Verificar si los números ingresados son válidos
  if (numeros.some(isNaN)) {
    document.getElementById('minimo').value = "¡Error! Ingresa solo números válidos."
    return
  }

  // Encontrar el número más pequeño usando Math.min() y el operador de propagación
  let minimo = Math.min(...numeros)

  // Mostrar el resultado en el área de texto
  document.getElementById('minimo').value = `El número más pequeño es: ${minimo}`
}
function arre6() {
  // Obtener los valores ingresados
  let datos = document.getElementById('numeros').value

  // Convertir los datos en un arreglo de números
  let numeros = datos.split(',').map(num => parseFloat(num.trim()))

  // Verificar que haya exactamente 10 números
  if (numeros.length !== 10) {
    document.getElementById('promedio').value = "¡Error! Ingrese exactamente 10 números."
    return
  }

  // se utiliza para Filtrar los números pares
  let numerosPares = numeros.filter(num => num % 2 === 0)

  // Verificar si hay números pares
  if (numerosPares.length === 0) {
    document.getElementById('promedio').value = "No hay números pares en el arreglo."
    return
  }

  // Sumar los números pares
  let sumaPares = numerosPares.reduce((acc, num) => acc + num, 0)

  // Calcular el promedio
  let promedio = sumaPares / numerosPares.length
  // Mostrar el promedio en el área de texto
  document.getElementById('promedio').value = `El promedio de los números pares es: ${promedio.toFixed(2)}`
}
    function arre7() {
      let numeros = document.getElementById('numeros').value
      if (numeros.trim() === "") {
          document.getElementById('resultado').value = "Por favor, ingrese números válidos separados por ``."
          return
      }

      let arregloNumeros = numeros.split(';').map(num => num.trim())

      let sumaTotal = 0
      arregloNumeros.forEach(num => {
         
          if (!isNaN(num)) {
              let digitos = num.split('').map(digit => parseInt(digit))
              let sumaDigitos = digitos.reduce((acc, digit) => acc + digit, 0)
              sumaTotal += sumaDigitos
          } else {
              document.getElementById('resultado').value = `Valor no válido: ${num}. Por favor ingrese solo números.`
              return
          }
      })

      document.getElementById('resultado').value = `La suma de los dígitos es: ${sumaTotal}`
  }
  function reiniciarCampos() {
      document.getElementById('numeros').value = ''
      document.getElementById('resultado').value = ''
  }
  function arre8() {
     let numeros = document.getElementById('numeros').value;

    // Verificar si se ingresaron números
    if (numeros.trim() === "") {
        document.getElementById('resultado').value = "Por favor, ingrese 10 números separados por `;`.";
        return;
    }

    // Convertir la cadena de números en un arreglo usando el delimitador ";"
     let arregloNumeros = numeros.split(';').map(num => num.trim());

    // Verificar si la cantidad de números es 10
    if (arregloNumeros.length !== 10) {
        document.getElementById('resultado').value = "Por favor, ingrese exactamente 10 números.";
        return;
    }

    let countPositivos = 0;
    let countNegativos = 0;
    let sumaPositivos = 0;
    let sumaNegativos = 0;

    arregloNumeros.forEach(num => {
        // Verificar si cada elemento es un número
        if (!isNaN(num)) {
            num = parseInt(num);
            if (num > 0) {
                countPositivos++;
                sumaPositivos += num;
            } else if (num < 0) {
                countNegativos++;
                sumaNegativos += num;
            }
        } else {
            document.getElementById('resultado').value = `Valor no válido: ${num}. Por favor ingrese solo números.`;
            return;
        }
    });

    // Mostrar los resultados en el área de texto
    document.getElementById('resultado').value = 
        `Positivos: ${countPositivos} (Suma: ${sumaPositivos})\n` +
        `Negativos: ${countNegativos} (Suma: ${sumaNegativos})`;
}

// Función para reiniciar los campos de entrada y resultado
function reiniciarCampos() {
    document.getElementById('numeros').value = ''; // Limpiar el campo de entrada
    document.getElementById('resultado').value = ''; // Limpiar el área de resultado
}
   // Función para calcular los cuadrados de los números
   function arre9() {
     let numeros = document.getElementById('numeros').value;

    // Verificar si se ingresaron números
    if (numeros.trim() === "") {
        document.getElementById('resultado').value = "Por favor, ingrese los números separados por `;`.";
        return;
    }

    // Convertir la cadena de números en un arreglo usando el delimitador ";"
     let arregloNumeros = numeros.split(';').map(num => num.trim());

    // Verificar que todos los elementos sean números válidos
    if (arregloNumeros.some(num => isNaN(num))) {
        document.getElementById('resultado').value = "Por favor, ingrese solo números válidos.";
        return;
    }

    // Crear el arreglo de los cuadrados de cada número
     let cuadrados = arregloNumeros.map(num => Math.pow(parseInt(num), 2));

    // Mostrar el resultado en el área de texto
    document.getElementById('resultado').value = `Arreglo con los cuadrados: [${cuadrados.join(', ')}]`;
}

// Función para reiniciar los campos de entrada y resultado
function reiniciarCampos() {
    document.getElementById('numeros').value = ''; // Limpiar el campo de entrada
    document.getElementById('resultado').value = ''; // Limpiar el área de resultado
}
function arre10() {
  const arreglo1 = document.getElementById('arreglo1').value;
  const arreglo2 = document.getElementById('arreglo2').value;

  // Verificar si los arreglos no están vacíos
  if (arreglo1.trim() === "" || arreglo2.trim() === "") {
      document.getElementById('resultado').value = "Por favor, ingrese ambos arreglos.";
      return;
  }

  // Convertir los arreglos de texto a arreglos de números usando el delimitador ","
  const arreglo1Numeros = arreglo1.split(',').map(num => num.trim());
  const arreglo2Numeros = arreglo2.split(',').map(num => num.trim());

  // Verificar que ambos arreglos tengan la misma longitud
  if (arreglo1Numeros.length !== arreglo2Numeros.length) {
      document.getElementById('resultado').value = "Los arreglos deben tener la misma longitud.";
      return;
  }

  // Verificar que todos los elementos sean números válidos
  if (arreglo1Numeros.some(num => isNaN(num)) || arreglo2Numeros.some(num => isNaN(num))) {
      document.getElementById('resultado').value = "Por favor, ingrese solo números válidos.";
      return;
  }

  // Sumar los elementos correspondientes de los dos arreglos
  const sumaArreglos = arreglo1Numeros.map((num, index) => parseInt(num) + parseInt(arreglo2Numeros[index]));

  // Mostrar el resultado en el área de texto
  document.getElementById('resultado').value = `Resultado de la suma: [${sumaArreglos.join(', ')}]`;
}

// Función para reiniciar los campos de entrada y resultado
function reiniciarCampos() {
  document.getElementById('arreglo1').value = ''
  document.getElementById('arreglo2').value = ''
  document.getElementById('resultado').value = ''
}